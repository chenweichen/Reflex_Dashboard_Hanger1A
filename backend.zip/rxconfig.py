import reflex as rx

config = rx.Config(
    app_name="Reflex_Dashboard_Hanger1A",
    api_url="http://localhost:8000",
)