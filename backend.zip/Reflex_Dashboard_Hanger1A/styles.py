

style: dict[str, dict[str, str]] = {
    ".cell-border":{
        "border":"solid",
    },
    ".cell-bgc-1":{
        "background_color":"#E8FFC4"
    },
    ".cell-bgc-2":{
        "background_color":"#97CBFF"
    },
    ".cell-bgc-3":{
        "background_color":"#FFDAC8"
    },
}